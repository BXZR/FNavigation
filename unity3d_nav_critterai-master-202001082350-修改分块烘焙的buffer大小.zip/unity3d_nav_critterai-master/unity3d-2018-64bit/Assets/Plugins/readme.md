��زο�:
References:
https://groups.google.com/forum/#!topic/critterai/IwV77mbj0ds
http://answers.unity3d.com/questions/265793/problem-in-bulding-exe-for-web-player.html
